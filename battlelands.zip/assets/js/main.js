jQuery(document).ready(function($) {
    if ($(window).width() < 1025) {

        var menuButton = document.querySelector('#nav-mobile-button-open'),
            menuButtonClose = document.querySelector('#nav-mobile-button-close');

        $('#nav-mobile-button-open').on('click', function(){
            $(this).addClass('expanded');
            $('#nav-mobile-button-close').removeClass('closed');
            $('.site-content-wrap > .menu').addClass('expanded');
        });
        
        $('#nav-mobile-button-close').on('click', function(){
            $(this).addClass('closed');
            $('#nav-mobile-button-open').removeClass('expanded');
            $('.site-content-wrap > .menu').removeClass('expanded');
        });
        
        /*
        var site_content = $('.site-content-wrap');
        site_content.addClass('swiper-wrapper');
        site_content.children('.menu, .content').addClass('swiper-slide');
        var openMenu = function () {
            menu_sidebar.slidePrev();
        };
        var menu_sidebar = new Swiper('#site-inner', {
            slidesPerView: 'auto',
            initialSlide: 1,
            resistanceRatio: 0,
            slideToClickedSlide: true,
            on: {
                slideChangeTransitionStart: function () {
                    var slider = this;
                    if (slider.activeIndex === 0) {
                        menuButton.classList.add('cross');
                        // required because of slideToClickedSlide
                        menuButton.removeEventListener('click', openMenu, true);
                    } else {
                        menuButton.classList.remove('cross');
                    }
                },
                slideChangeTransitionEnd: function () {
                    var slider = this;
                    if (slider.activeIndex === 1) {
                        menuButton.addEventListener('click', openMenu, true);
                    }
                },
            },
        });
        */
    }
    else {
    }

    const gameplay = new Swiper('.gameplay-slider', {
        // Optional parameters
        speed: 600,
        lazy: true,

        // If we need pagination
        pagination: {
            el: '.gameplay-pagination',
            clickable: true,
        },

        // Navigation arrows
        navigation: {
            nextEl: '.gameplay-button-next',
            prevEl: '.gameplay-button-prev',
        },

        // And if we need scrollbar
        scrollbar: {
            el: '.gameplay-scrollbar',
        },

        //Effects
        effect: 'fade',
        fadeEffect: {
            crossFade: true
        },
    });
});